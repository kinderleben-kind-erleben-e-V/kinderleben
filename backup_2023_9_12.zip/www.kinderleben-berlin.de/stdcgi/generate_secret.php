<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title>Secret Generator</title>
<body>
	<p>Benutzer und Passwort eingeben:</p>
	<form name="secret_generator" action="generate_secret.php" method="post">
	Benutzer: <input type="text" name="user">
	Passwort: <input type="password" name="password">
	<input type="submit" name="submit" value="Secret generieren">
	<?php
	if (!empty($_POST['user']) && !empty($_POST['password'])) {
		$secret = sha1($_POST['user'] . base64_encode($_POST['password']));
		echo "<pre>Secret: $secret</pre>";
	}
	?>
</body>
</html>
