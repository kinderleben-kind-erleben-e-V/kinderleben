<?php
/*
 * Created on 29.05.2008
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */
 function showTextEditor($xml,  &$editorOff){
	global $layoutWidth;
	//get Options
	$stdcgiOptionElement = $xml->xpath('/'.STDCGI_NAME);
	foreach($stdcgiOptionElement as $stdcgiOption){
		$editorMode = $stdcgiOption['editorMode'];
		$editorSkin = $stdcgiOption['editorSkin'];
	}
	//set options for the editor standard = off/false
	$editorOff = true;
	$editorSkinOn = false;
	$editorModeSimple = false;
	$editorModeNormal = false;
	$editorModeAdvanced = false;
	//we need to check the editor mode for the correct name
	switch($editorMode){
		case 'simple':
			$editorOff = false;
			$editorModeSimple = true;
			break;
		case 'normal':
			$editorOff = false;
			$editorModeNormal = true;
			break;
		case 'advanced':
			$editorOff = false;
			$editorModeAdvanced = true;
			break;
		case 'none':
			//$editorOff = true;
			break;
		default:
			//$editorOff = true;
			break;
	}
	//we check the editorSkin
	switch($editorSkin){
		case 'default':
			$editorSkin = '';
			$editorSkinOn = false;
			break;
		case 'black':
			$editorSkinOn = true;
			break;
		case 'blue':
			$editorSkin = 'default';
			$editorSkinOn = true;
			break;
		case 'silver':
			$editorSkinOn = true;
			break;
		case '':
			//$editorSkinOn = false;
			break;
		default:
			//$editorSkinOn = false;
			break;
	}
	if($editorModeSimple){
?>
tinyMCE.init({
			// General options Simple
			mode : "textareas",
			theme : "simple",
			force_br_newlines : true,
        	forced_root_block : ''
		});
<?
	}//end simple mode
	if($editorModeNormal){
?>
tinyMCE.init({
			// General options Normal
			mode : "textareas",
			theme : "advanced",
			force_br_newlines : true,
        	forced_root_block : '',
			<?
			if($editorSkinOn){
				echo 'skin : "o2k7",';
				echo "\n";
				echo '			skin_variant : "'.$editorSkin.'",';
				echo "\n";
			}
			?>
			plugins : "safari,pagebreak,style,layer,advhr,advimage,advlink,emotions,inlinepopups,directionality,visualchars,xhtmlxtras,template",
			language : "de",

			// Theme options
			<?if($layoutWidth >= 600){?>
			theme_advanced_buttons1 : "bold,italic,underline,|,forecolor,|,justifyleft,justifycenter,fontselect,|,bullist,numlist,|,link,image,emotions",
			theme_advanced_buttons2 : "",
			theme_advanced_buttons3 : "",
			<?}?>
			<?if($layoutWidth < 600){?>
			theme_advanced_buttons1 : "bold,italic,underline,|,emotions,|,fontselect,|,image",
			theme_advanced_buttons2 : "bullist,|,numlist,|,link,|,justifyleft,justifycenter,|,forecolor",
			theme_advanced_buttons3 : "",
			<?}?>
			<?if($layoutWidth <= 400){?>
			theme_advanced_buttons1 : "bold,italic,underline,|,emotions,|,fontselect",
			theme_advanced_buttons2 : "justifyleft,justifycenter,|,bullist,|,numlist,|,link,|,image,|,forecolor",
			theme_advanced_buttons3 : "",
			<?}?>
			<?if($layoutWidth <= 350){?>
			theme_advanced_buttons1 : "bold,italic,underline,|,justifyleft,justifycenter",
			theme_advanced_buttons2 : "fontselect,|,emotions",
			theme_advanced_buttons3 : "link,|,image,|,forecolor,|,bullist,numlist",
			<?}?>
			theme_advanced_buttons4 : "",
			theme_advanced_toolbar_location : "bottom",
			theme_advanced_toolbar_align : "center",
			theme_advanced_statusbar_location : "",
			theme_advanced_resizing : false,

			// Drop lists for link/image/media/template dialogs
			template_external_list_url : "libraries/tinymce/jscripts/tiny_mce/lists/template_list.js",
			external_link_list_url : "libraries/tinymce/jscripts/tiny_mce/lists/link_list.js",
			external_image_list_url : "libraries/tinymce/jscripts/tiny_mce/lists/image_list.js",
			media_external_list_url : "libraries/tinymce/jscripts/tiny_mce/lists/media_list.js",

			// Replace values for the template plugin
			template_replace_values : {
				username : "Editor",
				staffid : "991234"
			}
		});
	<?
	}//end normal mode
	if($editorModeAdvanced){
	?>
tinyMCE.init({
			// General options Advanced
			mode : "textareas",
			theme : "advanced",
			force_br_newlines : true,
        	forced_root_block : '',
			<?
			if($editorSkinOn){
				echo 'skin : "o2k7",';
				echo "\n";
				echo '			skin_variant : "'.$editorSkin.'",';
				echo "\n";
			}
			?>
			plugins : "safari,pagebreak,style,layer,table,advimage,advlink,emotions,iespell,inlinepopups,print,directionality,noneditable,visualchars,nonbreaking,xhtmlxtras,template",
			language : "de",

			// Theme options

			<?if($layoutWidth > 600){?>
			theme_advanced_buttons1 : "bold,italic,underline,strikethrough,charmap,|,justifyleft,justifycenter,justifyright,|,fontselect,fontsizeselect",
			theme_advanced_buttons2 : "bullist,numlist,|,outdent,indent,|,undo,redo,|,link,unlink,|,image,emotions,|,sup,|,hr,|,forecolor,|,backcolor",
			theme_advanced_buttons3 : "",
			theme_advanced_buttons4 : "",
			<?}?>
			<?if($layoutWidth <= 600){?>
			theme_advanced_buttons1 : "bold,italic,underline,strikethrough,charmap,|,justifyleft,justifycenter,justifyright,image",
			theme_advanced_buttons2 : "fontselect,fontsizeselect,|,emotions",
			theme_advanced_buttons3 : "bullist,numlist,|,outdent,indent,|,undo,redo,|,link,unlink",
			theme_advanced_buttons4 : "sup,hr,|,forecolor,backcolor",
			<?}?>
			theme_advanced_toolbar_location : "bottom",
			theme_advanced_toolbar_align : "center",
			theme_advanced_statusbar_location : "",
			theme_advanced_resizing : true,

			// Drop lists for link/image/media/template dialogs
			template_external_list_url : "libraries/tinymce/jscripts/tiny_mce/lists/template_list.js",
			external_link_list_url : "libraries/tinymce/jscripts/tiny_mce/lists/link_list.js",
			external_image_list_url : "libraries/tinymce/jscripts/tiny_mce/lists/image_list.js",
			media_external_list_url : "libraries/tinymce/jscripts/tiny_mce/lists/media_list.js",

			// Replace values for the template plugin
			template_replace_values : {
				username : "Editor",
				staffid : "991234"
			}
		});
<?
	}//end advanced mode
}
?>
