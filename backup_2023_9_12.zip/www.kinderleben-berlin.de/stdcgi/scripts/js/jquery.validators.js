$.extend($.validator.messages, {
	required: createInfoMessage("Dieses Feld wird benötigt"),
});

// numeric
jQuery.validator.addMethod(
	'numeric',
	function(value, element) {
		return this.optional(element) || value.match(/^[0-9]+$/) != null;
	},
	createErrorMessage('Der Wert muss numerisch sein.')
);

// alphanumeric
jQuery.validator.addMethod(
	'alphanumeric',
	function(value, element) {
		return this.optional(element) || value.match(/^[a-zA-Z0-9 öäüÜÄÖß.,:;&\/\-!?#&"`´%=(@*)!\n\r]+$/) != null;
	},
	createErrorMessage('Der Wert darf nur folgende Zeichen enthalten: a-zA-Z0-9 öäüÜÄÖß.,:;&\/\-!?#&%=@*()!' )
);

// mail
jQuery.validator.addMethod(
	'mail',
	function(value, element) {
		return this.optional(element) || value.match(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i ) != null;
	},
	createErrorMessage('Die angegebene E-Mail Adresse muss folgendes Format haben: name@domain.tld')
);

// url
jQuery.validator.addMethod(
	'url',
	function(value, element) {
		return this.optional(element) || value.match(/(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/) != null;
	},
	createErrorMessage('Der angegebenene Wert muss einer gültigen URL entsprechen: http://domain.tld oder http://www.domain.tld')
);