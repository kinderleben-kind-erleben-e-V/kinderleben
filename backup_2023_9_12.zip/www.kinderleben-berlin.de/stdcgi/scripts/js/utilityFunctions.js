var DATA_TYPE_UNDEFINED = 0;
var DATA_TYPE_BOOLEAN = 1;
var DATA_TYPE_DATE = 2;
var DATA_TYPE_DECIMAL = 3;
var DATA_TYPE_IMAGE = 4;
var DATA_TYPE_INTEGER = 5;
var DATA_TYPE_STRING = 6;
var DATA_TYPE_CHARACTER = 7;
var DATA_TYPE_EMAIL = 8;

var ERRORS = new Array();
ERRORS[0] = new Object();

function validate(element, dataType, maxLength)
{
	ERRORS[0][element.name] = false;

	switch(dataType) {
		case DATA_TYPE_BOOLEAN:
		case DATA_TYPE_INTEGER:
		case DATA_TYPE_DECIMAL:
			if(isNaN(element.value) == false) {
				ERRORS[0][element.name] = true;
			}
			break;

		case DATA_TYPE_DATE:
		case DATA_TYPE_IMAGE:
		case DATA_TYPE_STRING:
			if(element.value.length <= maxLength) {
				ERRORS[0][element.name] = true;
			} else {
				element.value = element.value.substr(0, maxLength);
			}
			break;
		case DATA_TYPE_CHARACTER:
		case DATA_TYPE_EMAIL:
			ERRORS[0][element.name] = true;
			var emailToSplit = element.value.replace(/ /gi,'');
			var lastCharacter = emailToSplit.length-1;
			var emailSplitted = emailToSplit.split(',');
			alert('emailSplitted 0: |' + emailSplitted[0] + '| => emailSplitted 1: |' + emailSplitted[1] + '|');
			for(var i = 0; i <= emailSplitted.length; i++) {
				if(emailSplitted[i].substr(lastCharacter) != ',' && emailSplitted[i]) {
					//alert(emailToSplit + '=>' + emailSplitted.length + ' => ' + emailSplitted[i]);
					reg = new RegExp(	'^([a-zA-Z0-9\\-\\.\\_]+)'+
										'(\\@)([a-zA-Z0-9\\-\\.]+)'+
										'(\\.)([a-zA-Z]{2,4})$');
					if((reg.test(emailSplitted[i])) === false){
						ERRORS[0][element.name] = false;
						break;
					}
					//alert(emailSplitted[i] + ' => '+ ERRORS[0][element.name])
				}
			}
			break;
	}
	if(ERRORS[0][element.name] == false) {
		element.style.color = 'red';
	} else {
		element.style.color = 'black';
	}
	return ERRORS[0][element.name];
}

function validateForm()
{
	var FORM_IS_VALIDATE = true;
	for (var FormField in ERRORS[0]) {
    	if(ERRORS[0][FormField] == false){
			FORM_IS_VALIDATE = false;
    	}
	}
	if(FORM_IS_VALIDATE == false){
		alert("Bitte korrigieren Sie erst die Rot markierten Felder.");
	}
	return FORM_IS_VALIDATE;
}


function ConfirmDeletion(message)
{
	/* Return: OK => true || Abbrechen => false*/
   	return confirm(message);
}

function changeVisibility(ID, display, displayNone){
	var div=document.getElementById(ID);
	if(div.style.display=="none"){
		if(display){
			div.style.display="block";
		}
	}
	else{
	 if(displayNone){
	 	div.style.display="none";
	 }
	}
}

function visibilityTable(ID, display, displayNone){
	var div=document.getElementById(ID);
	if(div.style.display=="none"){
		if(display){
			div.style.display="table-row";
		}
	}
	else{
	 if(displayNone){
	 	div.style.display="none";
	 }
	}
}

function createErrorMessage(message) {
	//return '<a class="errMsg" href="javascript:void(0)"><img src="images/exclamation.png" alt="" title="" /><span>' + message + '</span></a>';
	return '<img src="images/exclamation.png" title="' + message + '" />';
}

function createInfoMessage(message) {
	//return '<a class="infMsg" href="javascript:void(0)"><img src="images/information.png" alt="" title="" /><span>' + message + '</span></a>';
	return '<img src="images/information.png" title="' + message + '" />';
}
