<?php
/**
 * created on 29.05.2008
 * *
 * @author cr
 * @package .
 */

$response = 'none yet';

// INFO: check user client ip against config.xml
$isApprovedHost = false;
if(checkHostIP(getenv('REMOTE_ADDR')) === true) {
	$isApprovedHost = true;
} else {
	// TODO: error handling :: unapproved host encountered :-?
	$response = 'host ['.getenv('REMOTE_ADDR').'] is not allowed to access the standard cgis!';
}

if($isApprovedHost) {
	// INFO: create and store session id
	session_name('STDCGISID');
	session_start();
	// INFO: respond with url to 'local' customization script
	$response = 'http://'.getenv('SERVER_NAME').'/stdcgi/customization.php';
	//$response .= '?STDCGISN='.session_name();
	$response .= '?STDCGISID='.session_id();
	$_SESSION['authenticated'] = 1;
}

echo $response;

function checkHostIP($ip) {
	$isChecked = false;
	/*
	if($ip = '127.0.0.1') {
		$isChecked = true;
	}
	*/
	// INFO: open config.xml
	$config = openConfig();
	// INFO: read approved host ips and compare with passed parameter
	if($config != null) {
		$approvedHostIPs = $config->xpath('/config/approvedHosts/ip');
		foreach($approvedHostIPs as $approvedHostIP) {
			if($ip == $approvedHostIP) {
				$isChecked = true;
				break;
			}
		}
	}
	return $isChecked;
}

function openConfig() {
	$config = null;
	$configFileName = '../config.xml';
	if(file_exists($configFileName)) {
		$config = @simplexml_load_file($configFileName);
	} else {
		die("Datei '$configFileName' konnte nicht gefunden werden!");
	}
	return $config;
}